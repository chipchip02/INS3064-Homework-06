# Entity-Relationship Diagram (ERD) — Online Bookstore Database

## Entities & Attributes

### 1. authors
* **author_id** (PK, INT, Auto-Increment)
* `name` (VARCHAR, NOT NULL)
* `biography` (TEXT)
* `nationality` (VARCHAR)

### 2. publishers
* **publisher_id** (PK, INT, Auto-Increment)
* `name` (VARCHAR, NOT NULL, UNIQUE)
* `address` (TEXT)
* `website` (VARCHAR)

### 3. categories
* **category_id** (PK, INT, Auto-Increment)
* `name` (VARCHAR, NOT NULL, UNIQUE)
* `description` (TEXT)
* `parent_category_id` (FK, INT, NULL) - *Self-referencing for sub-genres*

### 4. books
* **book_id** (PK, INT, Auto-Increment)
* `title` (VARCHAR, NOT NULL)
* `isbn` (VARCHAR, NOT NULL, UNIQUE)
* `price` (DECIMAL(10,2), NOT NULL, CHECK > 0)
* `stock` (INT, NOT NULL, CHECK >= 0)
* `publication_date` (DATE)
* `publisher_id` (FK, INT, NOT NULL)

### 5. book_authors (Junction Table for M:N)
* **book_id** (PK/FK, INT)
* **author_id** (PK/FK, INT)

### 6. book_categories (Junction Table for M:N)
* **book_id** (PK/FK, INT)
* **category_id** (PK/FK, INT)

### 7. customers
* **customer_id** (PK, INT, Auto-Increment)
* `name` (VARCHAR, NOT NULL)
* `email` (VARCHAR, NOT NULL, UNIQUE)
* `password_hash` (VARCHAR, NOT NULL)
* `phone` (VARCHAR)
* `address` (TEXT)

### 8. orders
* **order_id** (PK, INT, Auto-Increment)
* `customer_id` (FK, INT, NOT NULL)
* `order_date` (DATETIME, DEFAULT CURRENT_TIMESTAMP)
* `status` (ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'), DEFAULT 'Pending')
* `total_amount` (DECIMAL(10,2), NOT NULL)
* `shipping_address` (TEXT, NOT NULL)

### 9. order_items
* **order_item_id** (PK, INT, Auto-Increment)
* `order_id` (FK, INT, NOT NULL)
* `book_id` (FK, INT, NOT NULL)
* `quantity` (INT, NOT NULL, CHECK > 0)
* `unit_price` (DECIMAL(10,2), NOT NULL)
* `subtotal` (DECIMAL(10,2), NOT NULL)

### 10. reviews
* **review_id** (PK, INT, Auto-Increment)
* `book_id` (FK, INT, NOT NULL)
* `customer_id` (FK, INT, NOT NULL)
* `rating` (INT, NOT NULL, CHECK (rating BETWEEN 1 AND 5))
* `comment` (TEXT)
* `created_at` (DATETIME, DEFAULT CURRENT_TIMESTAMP)

---

## Relationships & Cardinality

| Relationship | Type | Description |
| :--- | :--- | :--- |
| `publishers` to `books` | 1 : N | One publisher publishes many books; each book has one publisher. |
| `books` to `authors` | M : N | Resolved via `book_authors` junction table. |
| `books` to `categories` | M : N | Resolved via `book_categories` junction table. |
| `customers` to `orders` | 1 : N | One customer places many orders; each order belongs to one customer. |
| `orders` to `order_items` | 1 : N | One order contains many order items. |
| `books` to `order_items` | 1 : N | A book can appear in many order line items. |
| `customers` to `reviews` | 1 : N | One customer writes many reviews. |
| `books` to `reviews` | 1 : N | One book receives many reviews. |
-- =========================================================================
-- DATABASE DESIGN & NORMALIZATION EXPLANATION (Third Normal Form - 3NF)
-- =========================================================================
-- 1. First Normal Form (1NF): 
--    All table columns contain atomic (indivisible) values, and repeating 
--    groups have been eliminated. Multi-valued attributes like book authors 
--    and categories are separated into dedicated junction tables 
--    (book_authors, book_categories).
--
-- 2. Second Normal Form (2NF): 
--    The database is in 1NF, and all non-key attributes are fully functionally 
--    dependent on the entire primary key. In tables with composite primary keys 
--    (such as junction tables book_authors and book_categories), both columns 
--    make up the complete key, avoiding partial dependencies.
--
-- 3. Third Normal Form (3NF): 
--    The database is in 2NF, and there are no transitive dependencies (i.e., 
--    non-key attributes do not depend on other non-key attributes). For 
--    example, publisher details (address, website) are kept in the publishers 
--    table rather than repeated inside the books table, ensuring that changing 
--    a publisher's details only requires an update in one place.
-- =========================================================================

CREATE DATABASE IF NOT EXISTS bookstore_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bookstore_db;

-- Drop tables if they exist to allow clean re-importing
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS book_categories;
DROP TABLE IF EXISTS book_authors;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS publishers;
DROP TABLE IF EXISTS authors;

-- 1. Authors Table
CREATE TABLE authors (
    author_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    biography TEXT,
    nationality VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Publishers Table
CREATE TABLE publishers (
    publisher_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    address TEXT,
    website VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Categories Table
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    parent_category_id INT NULL,
    FOREIGN KEY (parent_category_id) REFERENCES categories(category_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Books Table
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    price DECIMAL(10,2) NOT NULL CHECK (price > 0),
    stock INT NOT NULL CHECK (stock >= 0),
    publication_date DATE,
    publisher_id INT NOT NULL,
    FOREIGN KEY (publisher_id) REFERENCES publishers(publisher_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Book-Authors Junction Table
CREATE TABLE book_authors (
    book_id INT NOT NULL,
    author_id INT NOT NULL,
    PRIMARY KEY (book_id, author_id),
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (author_id) REFERENCES authors(author_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Book-Categories Junction Table
CREATE TABLE book_categories (
    book_id INT NOT NULL,
    category_id INT NOT NULL,
    PRIMARY KEY (book_id, category_id),
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Customers Table
CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Orders Table
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled') DEFAULT 'Pending',
    total_amount DECIMAL(10,2) NOT NULL CHECK (total_amount >= 0),
    shipping_address TEXT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. Order Items Table
CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    book_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
    subtotal DECIMAL(10,2) NOT NULL CHECK (subtotal >= 0),
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. Reviews Table
CREATE TABLE reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    customer_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- =========================================================================
-- SAMPLE DATA INSERTION
-- =========================================================================

-- Authors (6 authors)
INSERT INTO authors (author_id, name, biography, nationality) VALUES
(1, 'J.K. Rowling', 'British author, best known for the Harry Potter series.', 'British'),
(2, 'George R.R. Martin', 'American novelist and short story writer, creator of A Song of Ice and Fire.', 'American'),
(3, 'J.R.R. Tolkien', 'English writer, poet, philologist, and academic, author of The Lord of the Rings.', 'British'),
(4, 'Agatha Christie', 'English writer known for her 66 detective novels.', 'British'),
(5, 'Stephen King', 'American author of horror, supernatural fiction, suspense, and fantasy.', 'American'),
(6, 'Haruki Murakami', 'Japanese writer whose works have been translated into 50 languages.', 'Japanese');

-- Publishers (4 publishers)
INSERT INTO publishers (publisher_id, name, address, website) VALUES
(1, 'Bloomsbury Publishing', '50 Bedford Square, London', 'https://www.bloomsbury.com'),
(2, 'Bantam Spectra', '1745 Broadway, New York', 'https://www.penguinrandomhouse.com'),
(3, 'HarperCollins', '195 Broadway, New York', 'https://www.harpercollins.com'),
(4, 'Vintage Books', '20 Vauxhall Bridge Rd, London', 'https://www.penguin.co.uk');

-- Categories (5 categories)
INSERT INTO categories (category_id, name, description, parent_category_id) VALUES
(1, 'Fiction', 'General fiction books and novels', NULL),
(2, 'Fantasy', 'Magical and supernatural tales', 1),
(3, 'Mystery', 'Whodunits and detective stories', 1),
(4, 'Horror', 'Scary and suspenseful fiction', 1),
(5, 'Classic', 'Timeless literary works', 1);

-- Books (8 books)
INSERT INTO books (book_id, title, isbn, price, stock, publication_date, publisher_id) VALUES
(1, 'Harry Potter and the Philosopher''s Stone', '9780747532699', 15.99, 50, '1997-06-26', 1),
(2, 'A Game of Thrones', '9780553103540', 25.50, 30, '1996-08-06', 2),
(3, 'The Hobbit', '9780261102217', 12.99, 45, '1937-09-21', 3),
(4, 'And Then There Were None', '9780007136834', 10.99, 40, '1939-11-06', 3),
(5, 'The Shining', '9780307743657', 14.50, 25, '1977-01-28', 2),
(6, 'Norwegian Wood', '9780307962973', 13.99, 35, '1987-09-04', 4),
(7, 'Harry Potter and the Chamber of Secrets', '9780747538493', 16.50, 40, '1998-07-02', 1),
(8, 'The Fellowship of the Ring', '9780261102354', 18.99, 20, '1954-07-29', 3);

-- Book Authors (M:N mapping)
INSERT INTO book_authors (book_id, author_id) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 1),
(8, 3);

-- Book Categories (M:N mapping)
INSERT INTO book_categories (book_id, category_id) VALUES
(1, 2), (1, 5),
(2, 2), (2, 1),
(3, 2), (3, 5),
(4, 3),
(5, 4),
(6, 1),
(7, 2),
(8, 2);

-- Customers (5 customers)
INSERT INTO customers (customer_id, name, email, password_hash, phone, address) VALUES
(1, 'Nguyen Van A', 'a.nguyen@gmail.com', '$2y$10$abcdefghijklmnopqrstuvwx', '0901234567', '123 Cau Giay, Hanoi'),
(2, 'Tran Thi B', 'b.tran@gmail.com', '$2y$10$abcdefghijklmnopqrstuvwx', '0912345678', '456 Le Duan, Hanoi'),
(3, 'Le Van C', 'c.le@gmail.com', '$2y$10$abcdefghijklmnopqrstuvwx', '0923456789', '789 Nguyen Hue, HCMC'),
(4, 'Pham Thi D', 'd.pham@gmail.com', '$2y$10$abcdefghijklmnopqrstuvwx', '0934567890', '10 Tran Hung Dao, Da Nang'),
(5, 'Hoang Van E', 'e.hoang@gmail.com', '$2y$10$abcdefghijklmnopqrstuvwx', '0945678901', '55 Phan Chu Trinh, Hue');

-- Orders (6 orders)
INSERT INTO orders (order_id, customer_id, order_date, status, total_amount, shipping_address) VALUES
(1, 1, '2026-06-01 10:30:00', 'Delivered', 31.98, '123 Cau Giay, Hanoi'),
(2, 2, '2026-06-02 14:15:00', 'Shipped', 25.50, '456 Le Duan, Hanoi'),
(3, 1, '2026-06-05 09:00:00', 'Processing', 23.98, '123 Cau Giay, Hanoi'),
(4, 3, '2026-06-06 16:45:00', 'Pending', 10.99, '789 Nguyen Hue, HCMC'),
(5, 4, '2026-06-08 11:20:00', 'Delivered', 14.50, '10 Tran Hung Dao, Da Nang'),
(6, 5, '2026-06-10 18:00:00', 'Shipped', 35.49, '55 Phan Chu Trinh, Hue');

-- Order Items (12+ order items)
INSERT INTO order_items (order_item_id, order_id, book_id, quantity, unit_price, subtotal) VALUES
(1, 1, 1, 1, 15.99, 15.99),
(2, 1, 7, 1, 16.50, 16.50),
(3, 2, 2, 1, 25.50, 25.50),
(4, 3, 3, 1, 12.99, 12.99),
(5, 3, 6, 1, 10.99, 10.99),
(6, 4, 4, 1, 10.99, 10.99),
(7, 5, 5, 1, 14.50, 14.50),
(8, 6, 8, 1, 18.99, 18.99),
(9, 6, 6, 1, 13.99, 13.99),
(10, 1, 3, 1, 12.99, 12.99),
(11, 2, 1, 1, 15.99, 15.99),
(12, 5, 4, 1, 10.99, 10.99);

-- Reviews (10 reviews)
INSERT INTO reviews (review_id, book_id, customer_id, rating, comment) VALUES
(1, 1, 1, 5, 'An absolute masterpiece of a magical world!'),
(2, 1, 2, 4, 'Really captivating and fun to read.'),
(3, 2, 3, 5, 'Complex characters and thrilling plot twists.'),
(4, 3, 4, 5, 'A classic fantasy adventure that never gets old.'),
(5, 4, 5, 4, 'Kept me guessing until the very last page!'),
(6, 5, 1, 4, 'Scary and brilliantly written by Stephen King.'),
(7, 6, 2, 5, 'Melancholic, beautiful, and deeply reflective.'),
(8, 7, 3, 5, 'A worthy sequel to the first Harry Potter book.'),
(9, 8, 4, 5, 'The beginning of the greatest epic fantasy ever told.'),
(10, 2, 5, 4, 'Brutal, realistic, and incredible world-building.');